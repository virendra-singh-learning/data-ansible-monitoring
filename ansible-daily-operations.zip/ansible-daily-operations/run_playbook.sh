#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Configuration
INVENTORY_FILE="inventory/hosts"
PLAYBOOK_FILE="playbook.yml"
LOG_DIR="logs"
LOG_FILE="$LOG_DIR/ansible_operations_$(date +%Y%m%d_%H%M%S).log"

# Create logs directory if it doesn't exist
mkdir -p "$LOG_DIR"

# Function to print colored output
print_color() {
    color=$1
    message=$2
    echo -e "${color}${message}${NC}"
}

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Function to show header
show_header() {
    clear
    print_color $CYAN "========================================="
    print_color $WHITE "    DAILY OPERATIONS MANAGEMENT"
    print_color $CYAN "========================================="
    echo
    print_color $YELLOW "Select the operation you want to run:"
    print_color $CYAN "--------------------------------------"
}

# Function to show menu options
show_menu() {
    echo " 1) Apache Server Ops          [apache_server]"
    echo " 2) NodeJS Heartbeat           [nodejs]"
    echo " 3) Sidekiq Process Check      [sidekiq]"
    echo " 4) Apache Logs                [apache_logs]"
    echo " 5) Sidekiq Logs               [sidekiq_logs]"
    echo " 6) PCC Workers Status         [pcc_workers]"
    echo " 7) CPU Load Check             [cpu_load]"
    echo " 8) MongoDB Statistics         [mongo_stats]"
    echo " 9) SCP File Copy              [scp]"
    echo "10) Mail Queue Check           [mailq]"
    echo "11) Disk Usage Check           [disk_usage]"
    echo "12) Postfix Logs               [postfix]"
    echo "13) Clear Mail Queue           [clear_mailq]"
    echo "14) PCC Workers Start/Stop     [pcc_workers_action]"
    echo "15) Multiple Operations        [custom]"
    echo " q) Quit"
    print_color $CYAN "--------------------------------------"
}

# Function to validate prerequisites
validate_prerequisites() {
    print_color $YELLOW "Checking prerequisites..."
    
    # Check if ansible is installed
    if ! command -v ansible-playbook &> /dev/null; then
        print_color $RED "ERROR: ansible-playbook not found. Please install Ansible."
        exit 1
    fi
    
    # Check if inventory file exists
    if [ ! -f "$INVENTORY_FILE" ]; then
        print_color $RED "ERROR: Inventory file $INVENTORY_FILE not found."
        exit 1
    fi
    
    # Check if playbook file exists
    if [ ! -f "$PLAYBOOK_FILE" ]; then
        print_color $RED "ERROR: Playbook file $PLAYBOOK_FILE not found."
        exit 1
    fi
    
    print_color $GREEN "Prerequisites check passed."
    echo
}

# Function to run ansible playbook with proper logging
run_ansible() {
    local tags=$1
    local extra_vars=$2
    local description=$3
    
    print_color $BLUE "Starting: $description"
    log_message "OPERATION START: $description"
    log_message "Tags: $tags"
    log_message "Extra vars: $extra_vars"
    
    local cmd="ansible-playbook -i $INVENTORY_FILE $PLAYBOOK_FILE --tags \"$tags\""
    if [ ! -z "$extra_vars" ]; then
        cmd="$cmd -e \"$extra_vars\""
    fi
    
    print_color $YELLOW "Executing: $cmd"
    echo
    
    # Execute the command and capture output
    eval $cmd 2>&1 | tee -a "$LOG_FILE"
    local exit_code=${PIPESTATUS[0]}
    
    echo
    if [ $exit_code -eq 0 ]; then
        print_color $GREEN "✓ Operation completed successfully: $description"
        log_message "OPERATION SUCCESS: $description"
    else
        print_color $RED "✗ Operation failed: $description (Exit code: $exit_code)"
        log_message "OPERATION FAILED: $description (Exit code: $exit_code)"
    fi
    
    return $exit_code
}

# Function to handle PCC workers start/stop with additional parameters
handle_pcc_workers_action() {
    print_color $CYAN "========================================="
    print_color $WHITE "PCC WORKERS START/STOP OPERATIONS"
    print_color $CYAN "========================================="
    echo
    
    # Get action (start/stop)
    print_color $YELLOW "Select action:"
    echo "1) Start workers"
    echo "2) Stop workers"
    echo "3) Restart workers"
    echo "4) Status check only"
    echo
    read -p "Enter your choice (1-4): " action_choice
    
    case $action_choice in
        1) pcc_action="start" ;;
        2) pcc_action="stop" ;;
        3) pcc_action="restart" ;;
        4) pcc_action="status" ;;
        *) 
            print_color $RED "Invalid choice. Defaulting to status check."
            pcc_action="status"
            ;;
    esac
    
    # Get queue names if not status
    if [ "$pcc_action" != "status" ]; then
        echo
        print_color $YELLOW "Available queue types:"
        echo "- monitoring_1"
        echo "- monitoring_2"
        echo "- data_processing"
        echo "- email_queue"
        echo "- maintenance_queue"
        echo "- backup_queue"
        echo
        print_color $YELLOW "Enter queue names (comma-separated) or press Enter for all:"
        read -p "> " queue_input
        
        if [ ! -z "$queue_input" ]; then
            # Convert comma-separated input to JSON array format
            IFS=',' read -ra QUEUES <<< "$queue_input"
            queue_json="["
            for i in "${!QUEUES[@]}"; do
                queue_name=$(echo "${QUEUES[$i]}" | xargs) # trim whitespace
                if [ $i -gt 0 ]; then
                    queue_json+=","
                fi
                queue_json+="\"$queue_name\""
            done
            queue_json+="]"
            selected_queues="$queue_json"
        else
            selected_queues='["monitoring_1","data_processing","email_queue"]'
        fi
    else
        selected_queues='[]'
    fi
    
    # Build extra vars
    extra_vars="pcc_action=$pcc_action selected_queues='$selected_queues'"
    
    # Run the operation
    run_ansible "pcc_workers_action" "$extra_vars" "PCC Workers $pcc_action Operation"
}

# Function to handle SCP operations
handle_scp_operation() {
    print_color $CYAN "========================================="
    print_color $WHITE "SCP FILE COPY OPERATIONS"
    print_color $CYAN "========================================="
    echo
    
    read -p "Enter source file path: " source_file
    read -p "Enter destination path (default: /tmp/): " dest_path
    
    if [ -z "$dest_path" ]; then
        dest_path="/tmp/"
    fi
    
    # Validate source file exists
    if [ ! -f "$source_file" ]; then
        print_color $RED "ERROR: Source file $source_file does not exist."
        return 1
    fi
    
    extra_vars="source_file=$source_file dest_path=$dest_path"
    
    run_ansible "scp" "$extra_vars" "SCP File Copy Operation"
}

# Function to handle multiple operations
handle_multiple_operations() {
    print_color $CYAN "========================================="
    print_color $WHITE "MULTIPLE OPERATIONS"
    print_color $CYAN "========================================="
    echo
    
    print_color $YELLOW "Available operation combinations:"
    echo "1) System Health Check (cpu_load,disk_usage,mailq)"
    echo "2) Application Stack Check (nodejs,sidekiq,apache_logs)"
    echo "3) Log Analysis (apache_logs,sidekiq_logs,postfix)"
    echo "4) Worker Services (sidekiq,pcc_workers)"
    echo "5) Database Operations (mongo_stats)"
    echo "6) Custom selection"
    echo
    
    read -p "Enter your choice (1-6): " multi_choice
    
    case $multi_choice in
        1) 
            tags="cpu_load,disk_usage,mailq"
            description="System Health Check"
            ;;
        2) 
            tags="nodejs,sidekiq,apache_logs"
            description="Application Stack Check"
            ;;
        3) 
            tags="apache_logs,sidekiq_logs,postfix"
            description="Log Analysis"
            ;;
        4) 
            tags="sidekiq,pcc_workers"
            description="Worker Services Check"
            ;;
        5) 
            tags="mongo_stats"
            description="Database Operations"
            ;;
        6) 
            echo
            print_color $YELLOW "Enter tags separated by commas (e.g., nodejs,sidekiq,cpu_load):"
            read -p "> " custom_tags
            tags="$custom_tags"
            description="Custom Operations"
            ;;
        *) 
            print_color $RED "Invalid choice."
            return 1
            ;;
    esac
    
    run_ansible "$tags" "" "$description"
}

# Function to show operation status and logs
show_status() {
    print_color $CYAN "========================================="
    print_color $WHITE "OPERATION STATUS"
    print_color $CYAN "========================================="
    echo
    
    if [ -f "$LOG_FILE" ]; then
        print_color $GREEN "Current log file: $LOG_FILE"
        echo
        print_color $YELLOW "Last 10 log entries:"
        tail -10 "$LOG_FILE"
    else
        print_color $YELLOW "No operations logged yet."
    fi
    
    echo
    print_color $BLUE "Press Enter to continue..."
    read
}

# Function to display help
show_help() {
    print_color $CYAN "========================================="
    print_color $WHITE "HELP & USAGE INFORMATION"
    print_color $CYAN "========================================="
    echo
    
    print_color $YELLOW "Interactive Operations (require server selection):"
    echo "• Apache Server Ops - Manage Apache web servers"
    echo "• PCC Workers Status - Check PCC worker processes"
    echo "• MongoDB Statistics - Get MongoDB performance data"
    echo "• PCC Workers Start/Stop - Control PCC worker queues"
    echo
    
    print_color $YELLOW "Automated Operations (run on predefined groups):"
    echo "• NodeJS Heartbeat - Check Node.js application health"
    echo "• Sidekiq Process Check - Monitor background job processors"
    echo "• Apache/Sidekiq/Postfix Logs - Analyze service logs"
    echo "• System monitoring - CPU load, disk usage, mail queue"
    echo
    
    print_color $YELLOW "Server Selection Options:"
    echo "• Individual servers: 1,3,5,8"
    echo "• Group selection: group:pcc-workers"
    echo "• All servers: 'all' or press Enter"
    echo
    
    print_color $YELLOW "Log Files:"
    echo "• Operation logs: $LOG_DIR/"
    echo "• Current session: $LOG_FILE"
    echo
    
    print_color $BLUE "Press Enter to continue..."
    read
}

# Main execution function
main() {
    # Validate prerequisites
    validate_prerequisites
    
    # Main loop
    while true; do
        show_header
        show_menu
        echo
        
        read -p "Enter the number corresponding to the task: " choice
        
        case $choice in
            1)
                run_ansible "apache_server" "" "Apache Server Operations"
                ;;
            2)
                run_ansible "nodejs" "" "NodeJS Heartbeat Check"
                ;;
            3)
                run_ansible "sidekiq" "" "Sidekiq Process Check"
                ;;
            4)
                run_ansible "apache_logs" "" "Apache Logs Analysis"
                ;;
            5)
                run_ansible "sidekiq_logs" "" "Sidekiq Logs Analysis"
                ;;
            6)
                run_ansible "pcc_workers" "" "PCC Workers Status Check"
                ;;
            7)
                run_ansible "cpu_load" "" "CPU Load Check"
                ;;
            8)
                run_ansible "mongo_stats" "" "MongoDB Statistics"
                ;;
            9)
                handle_scp_operation
                ;;
            10)
                run_ansible "mailq" "" "Mail Queue Check"
                ;;
            11)
                run_ansible "disk_usage" "" "Disk Usage Check"
                ;;
            12)
                run_ansible "postfix" "" "Postfix Logs Analysis"
                ;;
            13)
                run_ansible "clear_mailq" "" "Clear Mail Queue"
                ;;
            14)
                handle_pcc_workers_action
                ;;
            15)
                handle_multiple_operations
                ;;
            s|status)
                show_status
                continue
                ;;
            h|help)
                show_help
                continue
                ;;
            q|quit|exit)
                print_color $GREEN "Exiting Daily Operations Management."
                log_message "SESSION END: User requested exit"
                exit 0
                ;;
            *)
                print_color $RED "Invalid choice. Please try again."
                ;;
        esac
        
        echo
        print_color $BLUE "Operation completed. Press Enter to continue..."
        read
    done
}

# Function to handle command line arguments
handle_args() {
    case $1 in
        --help|-h)
            echo "Daily Operations Management Script"
            echo
            echo "Usage: $0 [OPTIONS]"
            echo
            echo "Options:"
            echo "  --help, -h          Show this help message"
            echo "  --list-tags         List available operation tags"
            echo "  --validate          Validate configuration only"
            echo "  --direct TAG        Run operation directly with tag"
            echo
            echo "Examples:"
            echo "  $0                  Start interactive menu"
            echo "  $0 --direct nodejs  Run nodejs check directly"
            echo "  $0 --validate       Check configuration"
            exit 0
            ;;
        --list-tags)
            echo "Available operation tags:"
            echo "  apache_server      - Apache web server management"
            echo "  nodejs            - Node.js application health check"
            echo "  sidekiq           - Sidekiq process monitoring"
            echo "  apache_logs       - Apache log analysis"
            echo "  sidekiq_logs      - Sidekiq log analysis"
            echo "  pcc_workers       - PCC worker status check"
            echo "  cpu_load          - System CPU load monitoring"
            echo "  mongo_stats       - MongoDB statistics"
            echo "  scp               - File copy operations"
            echo "  mailq             - Mail queue check"
            echo "  disk_usage        - Disk usage analysis"
            echo "  postfix           - Postfix log analysis"
            echo "  clear_mailq       - Clear mail queue"
            echo "  pcc_workers_action - PCC worker start/stop"
            exit 0
            ;;
        --validate)
            validate_prerequisites
            print_color $GREEN "Configuration validation successful."
            exit 0
            ;;
        --direct)
            if [ -z "$2" ]; then
                print_color $RED "ERROR: --direct requires a tag argument."
                exit 1
            fi
            validate_prerequisites
            run_ansible "$2" "" "Direct execution of $2"
            exit $?
            ;;
        "")
            # No arguments, run main interactive menu
            main
            ;;
        *)
            print_color $RED "Unknown argument: $1"
            echo "Use --help for usage information."
            exit 1
            ;;
    esac
}

# Script entry point
if [ "$#" -eq 0 ]; then
    main
else
    handle_args "$@"
fi
