# Ansible Infrastructure Management Playbook – Daily Operations

This follows the attached documentation exactly: interactive menu with 14 options, a single `playbook.yml`
using tags, and inventory-only changes.

## Quick Start
```bash
cd ansible-daily-ops
chmod +x run_playbook.sh
./run_playbook.sh
```

### Special case (Option 14: PCC Workers Start/Stop)
Set the parameters first (or the script will prompt you):
```bash
export PCC_ACTION=start        # or stop
export SELECTED_QUEUES='["monitoring_1","data_processing"]'
./run_playbook.sh
```

## Inventory-only changes
Add/edit hosts **only** in `inventory/hosts` – the menu and interactive selection will pick them up automatically.
