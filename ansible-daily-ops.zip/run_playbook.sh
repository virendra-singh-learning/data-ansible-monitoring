#!/usr/bin/env bash
set -euo pipefail

INV="inventory/hosts"
PLAYBOOK="playbook.yml"

print_menu() {
cat <<'EOF'
=========================================
    DAILY OPERATIONS MANAGEMENT
=========================================
Select the operation you want to run:
--------------------------------------
1)  Apache Server Ops        [apache_server]
2)  NodeJS Heartbeat         [nodejs]
3)  Sidekiq Process Check    [sidekiq]
4)  Apache Logs              [apache_logs]
5)  Sidekiq Logs             [sidekiq_logs]
6)  PCC Workers Status       [pcc_workers]
7)  CPU Load                 [cpu_load]
8)  Mongo Stats              [mongo_stats]
9)  SCP File Copy            [scp]
10) Mail Queue               [mailq]
11) Disk Usage               [disk_usage]
12) Postfix Logs             [postfix]
13) Clear Mail Queue         [clear_mailq]
14) PCC Workers Start/Stop   [pcc_workers_action]
--------------------------------------
Enter the number corresponding to the task:
EOF
}

INTERACTIVE_TAGS=("apache_server" "pcc_workers" "mongo_stats" "pcc_workers_action")

select_scope_interactive() {
  # Show hosts grouped
  echo "============================================="
  echo "INTERACTIVE TARGET SELECTION"
  echo "============================================="
  echo "Available Servers by Group:"
  echo "============================================="

  # Collect group->hosts list via ansible-inventory
  if command -v jq >/dev/null 2>&1; then
    INVJSON="$(ansible-inventory -i "$INV" --list)"
    mapfile -t GROUPS < <(echo "$INVJSON" | jq -r 'keys[]' | grep -v '^_meta$' | sort)
    idx=1
    HOSTS=()
    for G in "${GROUPS[@]}"; do
      HLIST=$(echo "$INVJSON" | jq -r --arg g "$G" '.[$g].hosts? // [] | .[]')
      if [ -n "$HLIST" ]; then
        echo ""
        echo "${G^^}:"
        while IFS= read -r H; do
          printf "%d. %s\n" "$idx" "$H"
          HOSTS+=("$H")
          ((idx++))
        done <<< "$HLIST"
      fi
    done
  else
    # Fallback: parse INI (simple)
    mapfile -t GROUPS < <(awk '/^\[.*\]/{gsub(/[\[\]]/,"");print $0}' "$INV" | sort | uniq)
    idx=1
    HOSTS=()
    for G in "${GROUPS[@]}"; do
      echo ""
      echo "${G^^}:"
      mapfile -t GLIST < <(awk -v g="[$G]" '
        $0==g {flag=1; next}
        /^\[.*\]/ {flag=0}
        flag && NF {print $1}
      ' "$INV")
      for H in "${GLIST[@]}"; do
        printf "%d. %s\n" "$idx" "$H"
        HOSTS+=("$H")
        ((idx++))
      done
    done
  fi

  echo ""
  cat <<'HINTS'
Select servers:
OPTIONS:
▸ Enter server numbers separated by commas (e.g., 1,3,8,11)
▸ Enter 'group:<name>' to select all servers in a group (e.g., group:pcc-worker)
▸ Enter 'all' to target all servers
▸ Press Enter to target all servers
HINTS
  read -rp "Your choice: " SEL

  if [ -z "${SEL:-}" ] || [[ "$SEL" == "all" ]]; then
    LIMIT="all"
  elif [[ "$SEL" == group:* ]]; then
    LIMIT="${SEL#group:}"
  else
    # Map indexes to hostnames
    IFS=',' read -ra IDX <<< "$SEL"
    OUT=()
    for id in "${IDX[@]}"; do
      id="$(echo "$id" | xargs)"
      if [[ "$id" =~ ^[0-9]+$ ]] && (( id>=1 && id<=${#HOSTS[@]} )); then
        OUT+=("${HOSTS[$((id-1))]}")
      else
        echo "Invalid selection index: $id" >&2
        exit 1
      fi
    done
    LIMIT="$(IFS=, ; echo "${OUT[*]}")"
  fi
}

ensure_params_pcc_action() {
  if [ -z "${PCC_ACTION:-}" ]; then
    read -rp "Enter PCC action (start/stop) [start]: " PCC_ACTION
    PCC_ACTION="${PCC_ACTION:-start}"
  fi
  if [ -z "${SELECTED_QUEUES:-}" ]; then
    read -rp "Enter queues as JSON array (e.g., [\"monitoring_1\",\"data_processing\"]) []: " SELECTED_QUEUES
    SELECTED_QUEUES="${SELECTED_QUEUES:-[]}"
  fi
  export PCC_ACTION SELECTED_QUEUES
}

print_menu
read -r CHOICE

declare -A MAP=(
  ["1"]="apache_server"
  ["2"]="nodejs"
  ["3"]="sidekiq"
  ["4"]="apache_logs"
  ["5"]="sidekiq_logs"
  ["6"]="pcc_workers"
  ["7"]="cpu_load"
  ["8"]="mongo_stats"
  ["9"]="scp"
  ["10"]="mailq"
  ["11"]="disk_usage"
  ["12"]="postfix"
  ["13"]="clear_mailq"
  ["14"]="pcc_workers_action"
)

TAG="${MAP[$CHOICE]:-}"
if [ -z "$TAG" ]; then
  echo "Invalid choice."
  exit 1
fi

LIMIT="all"
if printf '%s\0' "${INTERACTIVE_TAGS[@]}" | grep -Fqxz "$TAG"; then
  select_scope_interactive
  if [ "$TAG" = "pcc_workers_action" ]; then
    ensure_params_pcc_action
  fi
fi

echo ""
echo "Running: ansible-playbook -i $INV $PLAYBOOK --tags \"$TAG\" --limit \"$LIMIT\""
ANSIBLE_STDOUT_CALLBACK=yaml ansible-playbook -i "$INV" "$PLAYBOOK" --tags "$TAG" --limit "$LIMIT"
