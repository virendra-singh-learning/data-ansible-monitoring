# Ansible Production-Ready Starter

This repo gives you:
- A clean inventory where new servers or groups are added **only in inventory/hosts**.
- Multiple **playbooks** under `playbooks/` for common ops.
- A single **interactive runner** `run.sh` that lets you pick a playbook, then target:
  - one server
  - multiple servers
  - a group
  - or all hosts

Output is shown directly in your terminal with the YAML callback for readability.

## Quick start
```bash
cd ansible-prod-starter
chmod +x run.sh
./run.sh
```

## Inventory
Update `inventory/hosts` only. No other changes are required anywhere.

## Adding your own playbooks
Drop more files into `playbooks/` (e.g., `05_restart_service.yml`). They will automatically appear in the menu.
