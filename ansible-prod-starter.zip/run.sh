#!/usr/bin/env bash
set -euo pipefail

INV="inventory/hosts"

# Discover playbooks dynamically
mapfile -t PLAYBOOKS < <(ls -1 playbooks/*.yml | sort)
if [ ${#PLAYBOOKS[@]} -eq 0 ]; then
  echo "No playbooks found in playbooks/"; exit 1
fi

echo "======================================="
echo "        ANSIBLE OPERATIONS MENU        "
echo "======================================="
i=1
for pb in "${PLAYBOOKS[@]}"; do
  printf "%2d) %s\n" "$i" "$pb"
  ((i++))
done
echo "---------------------------------------"
read -rp "Select a playbook by number: " CHOICE

if ! [[ "$CHOICE" =~ ^[0-9]+$ ]] || (( CHOICE < 1 || CHOICE > ${#PLAYBOOKS[@]} )); then
  echo "Invalid selection"; exit 1
fi
PLAYBOOK="${PLAYBOOKS[$((CHOICE-1))]}"
echo "Selected: $PLAYBOOK"

echo ""
echo "Target scope:"
echo "  1) One server"
echo "  2) Multiple servers (comma-separated)"
echo "  3) A group"
echo "  4) All hosts"
read -rp "Choose 1-4: " SCOPE

LIMIT_ARG="all"

list_groups() {
  # Try to list groups using ansible-inventory + jq (best), fallback to parsing INI
  if command -v jq >/dev/null 2>&1; then
    ansible-inventory -i "$INV" --list | jq -r 'keys[]' | grep -v "^_meta$" | sort
  else
    # crude INI group parsing
    awk '/^\[.*\]/{gsub(/[\[\]]/,"");print $0}' "$INV" | sort | uniq
  fi
}

list_hosts_all() {
  ansible -i "$INV" all --list-hosts | awk 'NR>1{print $1}'
}

case "$SCOPE" in
  1)
    echo ""
    echo "Available hosts:"
    list_hosts_all || true
    read -rp "Enter a single host: " H
    LIMIT_ARG="$H"
    ;;
  2)
    echo ""
    echo "Available hosts:"
    list_hosts_all || true
    read -rp "Enter hosts (comma-separated): " HCSV
    LIMIT_ARG="$HCSV"
    ;;
  3)
    echo ""
    echo "Available groups:"
    list_groups || true
    read -rp "Enter a group name: " G
    LIMIT_ARG="$G"
    ;;
  4)
    LIMIT_ARG="all"
    ;;
  *)
    echo "Invalid choice"; exit 1
    ;;
esac

echo ""
echo "Running: ansible-playbook -i $INV "$PLAYBOOK" --limit "$LIMIT_ARG""
echo "---------------------------------------"
ANSIBLE_STDOUT_CALLBACK=yaml ansible-playbook -i "$INV" "$PLAYBOOK" --limit "$LIMIT_ARG"
